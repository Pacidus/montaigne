"""This is montaigne 

Montaigne is a object oriented pythonic interface for laboetie
"""

__all__ = ["simulation"]
__version__ = "0.0.4"
__author__ = "Yohan Duarte : pacidus@gmail.com"

from .simulation import simulation
